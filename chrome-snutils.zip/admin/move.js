
let data = `<?xml version="1.0" encoding="UTF-8"?>
<xml>
<incident>
<action_status/>
<actions_taken/>
<active>true</active>
<activity_due/>
<additional_assignee_list/>
<approval>not requested</approval>
<approval_history/>
<approval_set/>
<assigned_to/>
<assignment_group/>
<business_duration/>
<business_impact/>
<business_service/>
<business_stc/>
<calendar_duration/>
<calendar_stc/>
<caller_id>8a210a720f330010fe85fb8585767eec</caller_id>
<category>inquiry</category>
<cause/>
<caused_by/>
<child_incidents>0</child_incidents>
<close_code/>
<close_notes/>
<closed_at/>
<closed_by/>
<cmdb_ci/>
<comments/>
<comments_and_work_notes/>
<company/>
<contact_type/>
<contract/>
<correlation_display/>
<correlation_id/>
<delivery_plan/>
<delivery_task/>
<description/>
<due_date/>
<escalation>0</escalation>
<expected_start/>
<follow_up/>
<group_list/>
<hold_reason/>
<impact>3</impact>
<incident_state>1</incident_state>
<knowledge>false</knowledge>
<lessons_learned/>
<location/>
<made_sla>true</made_sla>
<major_incident_state/>
<needs_attention>false</needs_attention>
<notify>1</notify>
<number>INC0018659</number>
<opened_at>2023-09-14 22:39:41</opened_at>
<opened_by>fe4d1a4297cb8d1048a2fce3f153af56</opened_by>
<order/>
<origin_id/>
<origin_table/>
<overview/>
<parent/>
<parent_incident/>
<priority>5</priority>
<problem_id/>
<promoted_by/>
<promoted_on/>
<proposed_by/>
<proposed_on/>
<reassignment_count>0</reassignment_count>
<rejection_goto/>
<reopen_count>0</reopen_count>
<reopened_by/>
<reopened_time/>
<resolved_at/>
<resolved_by/>
<rfc/>
<route_reason/>
<sentiment/>
<service_offering/>
<severity>3</severity>
<short_description>Test</short_description>
<skills/>
<sla_due/>
<sn_esign_document/>
<sn_esign_esignature_configuration/>
<sn_hr_le_activity/>
<sn_ind_tsm_core_incident>true</sn_ind_tsm_core_incident>
<sn_ind_tsm_core_stage/>
<state>1</state>
<subcategory/>
<sys_class_name>incident</sys_class_name>
<sys_created_by>arnoud.kooi</sys_created_by>
<sys_created_on>2023-09-14 22:39:49</sys_created_on>
<sys_domain>global</sys_domain>
<sys_domain_path>/</sys_domain_path>
<sys_id>d77e7291971575102da5fcb3f153af0b</sys_id>
<sys_mod_count>0</sys_mod_count>
<sys_updated_by>arnoud.kooi</sys_updated_by>
<sys_updated_on>2023-09-14 22:39:49</sys_updated_on>
<task_effective_number>INC0018659</task_effective_number>
<time_worked/>
<timeline/>
<trigger_rule/>
<universal_request/>
<upon_approval>proceed</upon_approval>
<upon_reject>cancel</upon_reject>
<urgency>3</urgency>
<user_input/>
<variables/>
<watch_list/>
<wf_activity/>
<work_end/>
<work_notes/>
<work_notes_list/>
<work_start/>
</incident>
</xml>
`;
        const xmlString = '<root><child>content</child></root>';

        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(data, 'text/xml');
        const oldNode = xmlDoc.firstChild;
        const newNode = xmlDoc.createElement('unload');
        newNode.setAttribute("unload_date","2023-09-12 04:20:02");
        while (oldNode.firstChild) {
            newNode.appendChild(oldNode.firstChild);
        }
        oldNode.parentNode.replaceChild(newNode, oldNode);
        const serializer = new XMLSerializer();
        const newXmlString = serializer.serializeToString(xmlDoc);
        
        let blob = new Blob([newXmlString], { type: "text/xml" });
        const formData = new FormData();
        formData.append("sysparm_ck", "b3a449c5db553d10f0ff4e68139619f797701b6bfcddaf971bc5616d1d5effeb46dc3938");
        formData.append("sysparm_upload_prefix", "");
        formData.append("sysparm_referring_url", "");
        formData.append("sysparm_target", "");
        formData.append("attachFile", blob, "upload.xml");
        console.log(formData);
        fetch("https://empakooi.service-now.com/sys_upload.do", {
            method: "POST",
            headers: {
                'Content-Type': 'multipart/form-data',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'none',
                'Referer': location.href,
            },
            body: formData,
        }).catch((error) => ("Something went wrong!", error));
