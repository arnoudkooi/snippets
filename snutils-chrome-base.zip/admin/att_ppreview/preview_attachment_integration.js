/**
 * ServiceNow Utils Attachment Preview Integration
 * 
 * This script integrates the attachment preview wrapper into the main ServiceNow Utils functionality.
 * It detects the current environment (Classic UI or UI Builder) and loads the appropriate implementation.
 */

(function() {
    'use strict';
    
    /**
     * Check if we're in a UI Builder context
     * @returns {boolean} True if we're in UI Builder
     */
    function isUIBuilderEnvironment() {
        return window.NOW && window.NOW.UXF;
    }
    
    /**
     * Initialize the attachment preview functionality
     */
    function initAttachmentPreview() {
        // Check which environment we're in
        const isUIBuilder = isUIBuilderEnvironment();
        
        // Log environment for debugging
        console.log('[SN Utils] Running in ' + (isUIBuilder ? 'UI Builder' : 'Classic UI') + ' environment');
        
        // Load the common wrapper for both environments
        // This is included separately in the main inject.js file
        
        // Set up a polling mechanism to continually check for new attachment lists
        // This is particularly important for UI Builder where components may load dynamically
        setInterval(() => {
            if (typeof snuAddPreviewAttachmentLinks === 'function') {
                snuAddPreviewAttachmentLinks();
            }
        }, 3000);
        
        // If in UI Builder, add necessary styles for UI Builder compatibility
        if (isUIBuilder) {
            addUIBuilderStyles();
        }
    }
    
    /**
     * Add styles specific to UI Builder
     */
    function addUIBuilderStyles() {
        const styleElement = document.createElement('style');
        styleElement.id = 'snu-attachment-preview-styles';
        styleElement.textContent = `
            /* UI Builder specific styles */
            .snu-preview-link {
                cursor: pointer;
                margin-right: 5px;
                text-decoration: none;
                color: #1976d2;
                font-weight: bold;
            }
            
            /* Modal styles for UI Builder */
            .now-modal-container {
                z-index: 9999 !important; /* Ensure our modal is above other UI Builder elements */
            }
            
            /* Fix potential scrolling issues in UI Builder's attachment preview */
            .snu-csv-container {
                height: calc(100% - 30px) !important;
                overflow: hidden !important;
            }
            
            /* Shadow DOM compatibility styles */
            :host {
                all: initial;
                display: block;
            }
        `;
        
        document.head.appendChild(styleElement);
    }
    
    /**
     * Patch the global preview functions to work in both environments
     */
    function patchPreviewFunctions() {
        // This runs after the main wrapper script has loaded, so we'll wait for the functions
        const checkInterval = setInterval(() => {
            if (typeof window.snuPreviewAttachmentsModal === 'function') {
                clearInterval(checkInterval);
                
                // Save references to original functions
                const originalPreviewModal = window.snuPreviewAttachmentsModal;
                const originalAddLinks = window.snuAddPreviewAttachmentLinks;
                
                // Enhanced error handling for the preview modal
                window.snuPreviewAttachmentsModal = function(attSysId) {
                    try {
                        return originalPreviewModal(attSysId);
                    } catch (error) {
                        console.error('[SN Utils] Error in attachment preview modal:', error);
                        alert('SN Utils: Unable to show attachment preview. Check console for details.');
                    }
                };
                
                // Enhanced error handling for adding preview links
                window.snuAddPreviewAttachmentLinks = function() {
                    try {
                        return originalAddLinks();
                    } catch (error) {
                        console.error('[SN Utils] Error adding attachment preview links:', error);
                    }
                };
                
                // Run the function right away
                window.snuAddPreviewAttachmentLinks();
            }
        }, 500);
        
        // Safety timeout after 10 seconds
        setTimeout(() => clearInterval(checkInterval), 10000);
    }
    
    // Start the initialization when the document is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAttachmentPreview);
    } else {
        initAttachmentPreview();
    }
    
    // Patch functions after a short delay to ensure they're loaded
    setTimeout(patchPreviewFunctions, 1000);
    
    // Re-run initialization when navigating in UI Builder
    if (isUIBuilderEnvironment()) {
        // Listen for URL changes which might indicate navigation in UI Builder
        let lastUrl = location.href;
        new MutationObserver(() => {
            if (location.href !== lastUrl) {
                lastUrl = location.href;
                console.log('[SN Utils] URL changed, reinitializing attachment preview');
                setTimeout(initAttachmentPreview, 1000);
            }
        }).observe(document.body, {childList: true, subtree: true});
    }
})();
