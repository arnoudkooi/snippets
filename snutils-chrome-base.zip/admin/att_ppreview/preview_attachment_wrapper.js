/**
 * ServiceNow Utils Attachment Preview Wrapper
 * This provides a wrapper for the attachment preview functionality that works in both classic UI and UI Builder.
 */

(function() {
    'use strict';

    // Store reference to the current attachment index
    let snuCurrentAttatchmentIndex = -1;

    /**
     * Creates a modal to preview attachments that works in both classic UI and UI Builder
     * @param {string} attSysId - The sys_id of the attachment to preview initially (optional)
     */
    async function snuPreviewAttachmentsModal(attSysId) {
        // Check if we're in UI Builder context
        const isUIBuilder = window.NOW && window.NOW.UXF;
        
        // Fetch attachment data - need to handle this differently in UI Builder vs classic UI
        let data;
        try {
            if (isUIBuilder) {
                // In UI Builder, we need to use the appropriate API to get attachments
                // Using any available g_form instance or finding the record context
                const formElement = document.querySelector('.now-record-form-form');
                let table, sysId;
                
                if (formElement && formElement.dataset) {
                    // Extract table and sys_id from form element if available
                    table = formElement.dataset.table;
                    sysId = formElement.dataset.sysId;
                } else if (window.NOW.recordGlobal) {
                    // Try to get from NOW.recordGlobal
                    table = window.NOW.recordGlobal.table;
                    sysId = window.NOW.recordGlobal.sysId;
                } else if (g_form) {
                    // Fall back to g_form if available
                    table = g_form.getTableName();
                    sysId = g_form.getUniqueValue();
                }
                
                if (!table || !sysId) {
                    console.error('[SN Utils] Unable to determine table and record sys_id in UI Builder');
                    return;
                }
                
                // Get attachments using REST API
                data = await fetch(`/api/now/attachment?sysparm_query=table_name=${table}^table_sys_id=${sysId}&sysparm_limit=100`, {
                    headers: {
                        'X-UserToken': window.g_ck || '',
                        'Accept': 'application/json'
                    }
                }).then(response => response.json()).then(result => result.result);
            } else {
                // Classic UI - use g_form and snuFetchData
                data = await snuFetchData(g_ck, `/api/now/attachment?sysparm_query=table_name=${g_form.getTableName()}^table_sys_id=${g_form.getUniqueValue()}&sysparm_limit=100`);
                data = data?.result;
            }
            
            if (!data || !data.length) {
                console.log('[SN Utils] No attachments found');
                return;
            }
        } catch (error) {
            console.error('[SN Utils] Error fetching attachments:', error);
            return;
        }

        // Create container for attachment preview
        const container = document.createElement('div');
        container.id = 'snuAttachmentPreview';
        container.innerHTML = `
        <style>
            #snuAttachmentPreview {
                display: flex;
                width: 100%;
                height: 80vh;
                max-height: 80vh;
                overflow: hidden;
            }
            
            /* Modal container styles */
            .snu-modal-dialog {
                max-height: 90vh;
                width: 95%;
                margin: 0 auto;
            }
            
            /* UI-specific overrides */
            .now-modal-container #snuAttachmentPreview {
                height: 100%;
            }
            
            .now-modal-footer-buttons {
                justify-content: flex-end !important;
            }

            #snuAttatchmentNav {
                width: 20%;
                overflow-y: auto;
                flex-shrink: 0;
                padding: 0 5px;
                box-sizing: border-box;
            }

            #snuAttatchmentContent {
                width: 80%;
                padding: 5px;
                box-sizing: border-box;
                border: 1px solid #ccc;
                overflow: hidden;
                display: flex;
                flex-direction: column;
                height: 100%;
                max-height: 100%;
            }

            #snuAttatchmentNav ul {
                list-style-type: none;
                padding: 0;
                margin: 0;
            }

            #snuAttatchmentNav ul li {
                position: relative;
                padding-left: 16px; 
                margin-bottom: 3px;
                background-image: url('/images/icons/attach_text.gifx'); 
                background-size: 12px 12px;
                background-repeat: no-repeat; 
                background-position: left top;
                cursor: pointer;
            }

            #snuAttatchmentNav ul li a {
                text-decoration: none;
                color: #000;
                display: block;
            }

            #snuFilterAttachmentsInput { 
                width: 98%;
                padding: 2px;
                margin-bottom: 10px;
                border: 1px solid #ccc;
            }

            #snuFilterAttachmentsInput:focus {
                outline: none;
            }

            .emailtable, .emailtable td {
                padding-bottom: 4px;
                padding-right: 10px;
                vertical-align: top;
            }
            
            /* CSV table specific styles */
            .snu-csv-container {
                display: flex;
                flex-direction: column;
                height: 100%;
                width: 100%;
                overflow: hidden;
                max-height: calc(100% - 30px);
            }
            
            .snu-csv-controls {
                flex-shrink: 0;
                position: sticky;
                top: 0;
                z-index: 10;
                background: #f5f5f5;
                padding: 5px;
                border-bottom: 1px solid #ddd;
                display: flex;
                flex-wrap: wrap;
                align-items: center;
            }
            
            .snu-csv-table-container {
                overflow: auto;
                flex-grow: 1;
            }
            
            .snu-csv-table {
                border-collapse: collapse;
                width: 100%;
            }
            
            .snu-csv-table th,
            .snu-csv-table td {
                border: 1px solid #ddd;
                padding: 4px;
                max-width: 200px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            
            .snu-csv-table th {
                background-color: #f0f0f0;
                position: sticky;
                top: 0;
                z-index: 1;
            }
            
            /* Shadow DOM compatibility */
            :host {
                display: block;
                width: 100%;
                height: 100%;
            }
        </style>
        <div id="snuAttatchmentNav">
            <input type="search" autocomplete="off" id="snuFilterAttachmentsInput" placeholder="Filter attachments...">
            <ul></ul>
        </div>
        <div id="snuAttatchmentContent">
            <p>Select an attachment to preview it.</p>
            <p>Preview attachments, view, and download via the classic way.</p>
        </div>`;

        // Format file size helper function
        function formatFileSize(bytes) {
            const sizes = ['bytes', 'KB', 'MB', 'GB', 'TB'];
            if (bytes === 0) return '0 b';
            const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)), 10);
            return `${(bytes / (1024 ** i)).toFixed(0)} ${sizes[i]}`;
        }

        // Populate the attachments list
        const attachmentList = container.querySelector("ul");
        let storedAtt;
        
        data.forEach(att => {
            const parts = att.file_name.split('.');
            att.extension = parts.length > 1 ? parts.pop().toLowerCase() : '';

            const listItem = document.createElement('li');
            listItem.style.fontSize = '9pt';
            listItem.id = 'att_' + att.sys_id;
            listItem.tabIndex = 0;
            listItem.onclick = () => snuSetAttachmentPreview(att);
            const fileSize = formatFileSize(parseInt(att.size_bytes, 10));
            listItem.textContent = `${att.file_name} (${fileSize})`;
            listItem.title = `${att.content_type} | ${att.sys_updated_by} | ${att.sys_updated_on}`;
            listItem.dataset.type = att.content_type;

            // Set appropriate icon based on file type
            if (att.content_type.includes('image')) 
                listItem.style.backgroundImage = 'url(/images/icons/attach_image.gifx)';
            else if (att.content_type.includes('video')) 
                listItem.style.backgroundImage = 'url(/images/icons/attach_video.gifx)';
            else if (att.content_type.includes('audio')) 
                listItem.style.backgroundImage = 'url(/images/icons/attach_audio.gifx)';
            else if (att.content_type.includes('zip')) 
                listItem.style.backgroundImage = 'url(/images/icons/attach_zip.gifx)';
            else if (att.extension.startsWith('xls')) 
                listItem.style.backgroundImage = 'url(/images/icons/attach_excel.gifx)';
            else if (att.extension.startsWith('doc')) 
                listItem.style.backgroundImage = 'url(/images/icons/attach_word.gifx)';
            else if (att.extension.startsWith('ppt')) 
                listItem.style.backgroundImage = 'url(/images/icons/attach_project.gifx)';
            else if (att.extension.startsWith('xml')) 
                listItem.style.backgroundImage = 'url(/images/icons/attach_xml.gifx)';
            else if (['csv'].includes(att.extension)) 
                listItem.style.backgroundImage = 'url(/images/icons/attach_excel.gifx)';
            else if (['msg','eml'].includes(att.extension)) 
                listItem.style.backgroundImage = 'url(/images/icons/email.gifx)';
            else if (['ics'].includes(att.extension)) 
                listItem.style.backgroundImage = 'url(/images/icons/time.gifx)';
            else if (att.extension === 'pdf') 
                listItem.style.backgroundImage = 'url(/images/icons/attach_pdf.gifx)';

            attachmentList.appendChild(listItem);

            // If this attachment matches the initial selected one
            if (att.sys_id === attSysId) {
                listItem.style.fontWeight = 'bold';
                storedAtt = att;
            }
        });

        // Function to handle attachment selection (keyboard navigation)
        let filterdItems = Array.from(document.querySelectorAll('#snuAttatchmentNav ul li'));
      
        // Function to update the focus and highlight the current item
        function snuUpdateAttachmentFocus(index) {
            filterdItems.forEach((item, idx) => {
                if (idx === index) {
                    item.style.fontWeight = 'bold';
                    item.focus();
                    item.click();
                } else {
                    item.style.fontWeight = 'normal';
                }
            });
        }

        // Show the modal based on environment
        if (isUIBuilder) {
            // UI Builder - use Now Experience modal
            showNowExperienceModal(container, storedAtt);
        } else {
            // Classic UI - use GlideModal
            showClassicModal(container, storedAtt);
        }

        // Add event listeners
        setUpEventListeners(attachmentList, filterdItems);
    }

    /**
     * Show modal using the Now Experience UI Framework
     * @param {HTMLElement} container - The container element
     * @param {Object} storedAtt - The initial attachment to display
     */
    function showNowExperienceModal(container, storedAtt) {
        // Create a wrapper for the Now modal
        const modalWrapper = document.createElement('div');
        modalWrapper.id = 'snuPreviewAttachmentsModal';
        modalWrapper.className = 'now-modal-container';
        
        // Create modal structure
        modalWrapper.innerHTML = `
            <div class="now-modal-window">
                <div class="now-modal-header">
                    <h2 class="now-modal-title">[SN Utils] Preview Attachments</h2>
                    <button class="now-modal-close-button" aria-label="Close">×</button>
                </div>
                <div class="now-modal-content"></div>
                <div class="now-modal-footer">
                    <div class="now-modal-footer-buttons">
                        <button class="now-modal-close-btn">Close</button>
                    </div>
                </div>
            </div>
        `;
        
        // Add modal style
        const modalStyle = document.createElement('style');
        modalStyle.textContent = `
            .now-modal-container {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background-color: rgba(0, 0, 0, 0.5);
                z-index: 9999;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            
            .now-modal-window {
                background-color: #fff;
                border-radius: 4px;
                width: 90%;
                max-width: 95%;
                max-height: 90vh;
                display: flex;
                flex-direction: column;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            }
            
            .now-modal-header {
                padding: 12px 16px;
                border-bottom: 1px solid #e0e0e0;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            
            .now-modal-title {
                margin: 0;
                font-size: 1.25rem;
                font-weight: 600;
            }
            
            .now-modal-close-button {
                background: none;
                border: none;
                font-size: 1.5rem;
                cursor: pointer;
                padding: 0;
                color: #666;
            }
            
            .now-modal-content {
                padding: 16px;
                overflow: auto;
                flex-grow: 1;
                min-height: 200px;
            }
            
            .now-modal-footer {
                padding: 12px 16px;
                border-top: 1px solid #e0e0e0;
            }
            
            .now-modal-footer-buttons {
                display: flex;
                justify-content: flex-end;
            }
            
            .now-modal-close-btn {
                padding: 6px 16px;
                background-color: #f0f0f0;
                border: 1px solid #ccc;
                border-radius: 4px;
                cursor: pointer;
            }
        `;
        
        // Append modal to body
        document.body.appendChild(modalStyle);
        document.body.appendChild(modalWrapper);
        
        // Add container to modal content
        const modalContent = modalWrapper.querySelector('.now-modal-content');
        modalContent.appendChild(container);
        
        // Add close functionality
        modalWrapper.querySelector('.now-modal-close-button').addEventListener('click', () => {
            document.body.removeChild(modalStyle);
            document.body.removeChild(modalWrapper);
        });
        
        modalWrapper.querySelector('.now-modal-close-btn').addEventListener('click', () => {
            document.body.removeChild(modalStyle);
            document.body.removeChild(modalWrapper);
        });
        
        // Show initial attachment
        if (storedAtt) snuSetAttachmentPreview(storedAtt);
    }

    /**
     * Show modal using the classic GlideModal
     * @param {HTMLElement} container - The container element
     * @param {Object} storedAtt - The initial attachment to display
     */
    function showClassicModal(container, storedAtt) {
        const modal = new GlideModal('snuPreviewAttachments');
        modal.setTitle('[SN Utils] Preview Attachments');
        modal.setBody(container);
        
        // Ensure modal is wide enough
        setTimeout(() => {
            document.querySelector('#snuPreviewAttachments .modal-dialog').style.width = '95%';
        }, 0);
        
        // Show initial attachment
        if (storedAtt) snuSetAttachmentPreview(storedAtt);
    }

    /**
     * Set up event listeners for the attachment preview modal
     * @param {HTMLElement} attachmentList - The list element containing attachments
     * @param {Array} filterdItems - Array of filtered list items
     */
    function setUpEventListeners(attachmentList, filterdItems) {
        // Allow key up/down navigation
        attachmentList.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                snuCurrentAttatchmentIndex = (snuCurrentAttatchmentIndex + 1) % filterdItems.length;
                snuUpdateAttachmentFocus(snuCurrentAttatchmentIndex);
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                snuCurrentAttatchmentIndex = (snuCurrentAttatchmentIndex - 1 + filterdItems.length) % filterdItems.length;
                snuUpdateAttachmentFocus(snuCurrentAttatchmentIndex);
            }
        });

        // Add filter functionality
        document.querySelector('#snuFilterAttachmentsInput').addEventListener('keyup', (e) => {
            const filterValue = e.target.value.toLowerCase();
            const filterWords = filterValue.split(' ');
            const listItems = document.querySelectorAll('#snuAttatchmentNav ul li');
            
            filterdItems = [];
            listItems.forEach(function(item) {
                const text = item.textContent.toLowerCase() + ' ' + item?.dataset?.type.toLowerCase();
                const matches = filterWords.every(word => text.includes(word));
                if (matches) {
                    item.style.display = '';
                    filterdItems.push(item);
                } else {
                    item.style.display = 'none';
                }
            });

            if (e.key === 'ArrowDown') {
                e.preventDefault();
                snuUpdateAttachmentFocus(0);
            }
        });
        
        document.querySelector('#snuFilterAttachmentsInput').focus();
    }

    /**
     * Set the preview content for an attachment
     * @param {Object} att - The attachment object
     */
    async function snuSetAttachmentPreview(att) {
        let idx = 0;
        document.querySelectorAll('#snuAttatchmentNav ul li').forEach(li => {
            li.style.fontWeight = 'normal';
            if (li.id == 'att_' + att.sys_id) {
                li.style.fontWeight = 'bold';
                snuCurrentAttatchmentIndex = idx;
            }
            idx++;
        });

        if (att.content_type.includes('image')) {
            const content = document.querySelector('#snuAttatchmentContent');
            content.innerHTML = '';
            const img = document.createElement('img');
            img.src = `${att.sys_id}.iix`;
            img.style.maxWidth = '100%';
            img.style.maxHeight = '100%';
            content.appendChild(img);
        }
        else if (att.content_type.includes('video')) {  
            const content = document.querySelector('#snuAttatchmentContent');
            content.innerHTML = '';
            const video = document.createElement('video');
            video.src = `/sys_attachment.do?sys_id=${att.sys_id}`;
            video.controls = true;
            video.style.maxWidth = '100%';
            video.style.maxHeight = '100%';
            content.appendChild(video);
        }   
        else if (att.content_type.includes('audio')) {
            const content = document.querySelector('#snuAttatchmentContent');
            content.innerHTML = '';
            const audio = document.createElement('audio');
            audio.src = `/sys_attachment.do?sys_id=${att.sys_id}`;
            audio.controls = true;
            audio.style.width = '100%';
            content.appendChild(audio);
        }
        else if (['pdf'].includes(att.extension)) {
            const content = document.querySelector('#snuAttatchmentContent');
            content.innerHTML = 'PDF being loaded, please wait...';
            try {
                const response = await fetch(`/sys_attachment.do?sys_id=${att.sys_id}`);
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const blob = await response.blob();
                const url = URL.createObjectURL(blob);
                const iframe = document.createElement('iframe');
                content.innerHTML = '';
                iframe.src = url;
                iframe.style.width = '100%';
                iframe.style.height = '100%';
                iframe.style.border = 'none';
                content.appendChild(iframe);
            } catch (error) {
                const content = document.querySelector('#snuAttatchmentContent');
                content.innerHTML = 'Error loading PDF:' + error.message;
            }
        }
        else if (['doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx'].includes(att.extension)) {
            const content = document.querySelector('#snuAttatchmentContent');
            content.innerHTML = '';
            const iframe = document.createElement('iframe');
            iframe.src = `/$viewer.do?sysparm_stack=no&sysparm_sys_id=${att.sys_id}`;
            iframe.style.width = '100%';
            iframe.style.height = '100%';
            content.appendChild(iframe);
        }
        else if (['csv'].includes(att.extension)) {
            const content = document.querySelector('#snuAttatchmentContent');
            content.innerHTML = 'CSV file is being loaded, please wait...';
            
            let fileContent = await fetch(`/sys_attachment.do?sys_id=${att.sys_id}`).then(response => response.text());
            content.innerHTML = '';
            let span = document.createElement('span');
            span.innerHTML = `
            Download: <a href="/sys_attachment.do?sys_id=${att.sys_id}">${att.file_name}</a> | 
            <a href="#" title="[SN Utils] Copy result to clipboard" onclick="snuCopyAttatchmentContent()" >
            <svg class="w-6 h-6 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" stroke-linejoin="round" stroke-width="2" d="M9 8v3a1 1 0 0 1-1 1H5m11 4h2a1 1 0 0 0 1-1V5a1 1 0 0 0-1-1h-7a1 1 0 0 0-1 1v1m4 3v10a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1v-7.13a1 1 0 0 1 .24-.65L7.7 8.35A1 1 0 0 1 8.46 8H13a1 1 0 0 1 1 1Z"/>
            </svg>
            </a><span id="actionResult"></span>`;
            content.appendChild(span);
            
            // Parse CSV
            try {
                // Clear existing content (keep only the download span we already added)
                const downloadSpan = content.querySelector('span');
                content.innerHTML = '';
                content.appendChild(downloadSpan);
                
                // Create a wrapper for all CSV content
                const csvWrapper = document.createElement('div');
                csvWrapper.className = 'snu-csv-container';
                
                // Create search and display controls first - this needs to stay fixed at the top
                const searchDiv = document.createElement('div');
                searchDiv.className = 'snu-csv-controls';
                
                // Create search input
                const searchInput = document.createElement('input');
                searchInput.type = 'search';
                searchInput.placeholder = 'Search in CSV...';
                searchInput.style.marginRight = '10px';
                searchInput.id = 'csvSearchInput';
                searchDiv.appendChild(searchInput);
                
                // Create expand/collapse button
                const expandButton = document.createElement('button');
                expandButton.textContent = 'Expand Columns';
                expandButton.id = 'csvExpandColumnsBtn';
                expandButton.setAttribute('data-expanded', 'false');
                expandButton.style.marginRight = '10px';
                searchDiv.appendChild(expandButton);
                
                // Create fit columns button
                const fitColumnsButton = document.createElement('button');
                fitColumnsButton.textContent = 'Fit Columns';
                fitColumnsButton.id = 'csvFixColumnWidthsBtn';
                searchDiv.appendChild(fitColumnsButton);
                
                csvWrapper.appendChild(searchDiv);
                
                // Create table container with automatic scroll
                const tableContainer = document.createElement('div');
                tableContainer.className = 'snu-csv-table-container';
                
                // Parse the CSV
                const lines = fileContent.split(/\r?\n/);
                const table = document.createElement('table');
                table.id = 'snuCsvTable';
                table.className = 'snu-csv-table';
                table.style.tableLayout = 'fixed';
                
                // Process header row first
                if (lines.length > 0) {
                    const headerRow = document.createElement('tr');
                    const headerCells = parseCSVLine(lines[0]);
                    
                    headerCells.forEach(cell => {
                        const th = document.createElement('th');
                        th.textContent = cell;
                        th.style.maxWidth = '200px';
                        th.style.overflow = 'hidden';
                        th.style.textOverflow = 'ellipsis';
                        th.style.whiteSpace = 'nowrap';
                        headerRow.appendChild(th);
                    });
                    
                    table.appendChild(headerRow);
                    
                    // Process data rows
                    for (let i = 1; i < lines.length; i++) {
                        if (!lines[i].trim()) continue; // Skip empty lines
                        
                        const dataRow = document.createElement('tr');
                        const dataCells = parseCSVLine(lines[i]);
                        
                        dataCells.forEach(cell => {
                            const td = document.createElement('td');
                            td.textContent = cell;
                            td.style.maxWidth = '200px';
                            td.style.overflow = 'hidden';
                            td.style.textOverflow = 'ellipsis';
                            td.style.whiteSpace = 'nowrap';
                            dataRow.appendChild(td);
                        });
                        
                        table.appendChild(dataRow);
                    }
                }
                
                tableContainer.appendChild(table);
                csvWrapper.appendChild(tableContainer);
                content.appendChild(csvWrapper);
                
                // Add search functionality
                document.getElementById('csvSearchInput').addEventListener('keyup', function() {
                    const searchValue = this.value.toLowerCase();
                    const tableRows = document.querySelectorAll('#snuCsvTable tr');
                    let visibleCount = 0;
                    
                    for (let i = 1; i < tableRows.length; i++) { // Start from 1 to skip header
                        const row = tableRows[i];
                        const textContent = row.textContent.toLowerCase();
                        
                        if (textContent.includes(searchValue)) {
                            row.style.display = '';
                            visibleCount++;
                        } else {
                            row.style.display = 'none';
                        }
                    }
                    
                    // Show a message when no results are found
                    const existingMsg = document.getElementById('noResultsMessage');
                    if (visibleCount === 0 && searchValue) {
                        if (!existingMsg) {
                            const msg = document.createElement('div');
                            msg.id = 'noResultsMessage';
                            msg.textContent = 'No matching results found';
                            msg.style.padding = '10px';
                            msg.style.color = '#666';
                            msg.style.fontStyle = 'italic';
                            msg.style.textAlign = 'center';
                            const tableContainer = document.getElementById('snuCsvTable').parentElement;
                            tableContainer.appendChild(msg);
                        }
                    } else if (existingMsg) {
                        existingMsg.remove();
                    }
                });
                
                // Add expand columns button functionality
                document.getElementById('csvExpandColumnsBtn').addEventListener('click', function() {
                    const tableCells = document.querySelectorAll('#snuCsvTable th, #snuCsvTable td');
                    const table = document.getElementById('snuCsvTable');
                    const tableContainer = table.parentElement;
                    const isExpanded = this.getAttribute('data-expanded') === 'true';
                    
                    if (isExpanded) {
                        // Collapse columns
                        table.style.tableLayout = 'fixed';
                        tableCells.forEach(cell => {
                            // Restore original widths
                            const baseColumnWidth = cell.getAttribute('data-original-width');
                            if (baseColumnWidth) {
                                cell.style.maxWidth = baseColumnWidth;
                                cell.style.minWidth = '80px';
                            }
                            cell.style.overflow = 'hidden';
                            cell.style.textOverflow = 'ellipsis';
                            cell.style.whiteSpace = 'nowrap';
                        });
                        // Ensure table respects container boundaries
                        table.style.maxWidth = '100%';
                        tableContainer.style.overflowX = 'auto';
                        this.textContent = 'Expand Columns';
                        this.setAttribute('data-expanded', 'false');
                    } else {
                        // Expand columns
                        table.style.tableLayout = 'auto';
                        tableCells.forEach(cell => {
                            // Store original width for later restoration
                            if (!cell.getAttribute('data-original-width')) {
                                cell.setAttribute('data-original-width', cell.style.maxWidth);
                            }
                            cell.style.maxWidth = 'none';
                            cell.style.overflow = 'visible';
                            cell.style.whiteSpace = 'pre-wrap';
                            cell.style.wordBreak = 'break-word';
                        });
                        // When expanded, ensure horizontal scrolling is enabled but table stays within viewport width
                        tableContainer.style.overflowX = 'auto';
                        table.style.maxWidth = 'none'; // Allow table to be wider than container for scrolling
                        this.textContent = 'Collapse Columns';
                        this.setAttribute('data-expanded', 'true');
                    }
                });
                
                // Add fit columns button functionality - auto-size columns to content
                document.getElementById('csvFixColumnWidthsBtn').addEventListener('click', function() {
                    const table = document.getElementById('snuCsvTable');
                    const tableContainer = table.parentElement;
                    const headerRow = table.querySelector('tr');
                    const isExpanded = document.getElementById('csvExpandColumnsBtn').getAttribute('data-expanded') === 'true';
                    
                    // Only work in non-expanded mode
                    if (isExpanded) {
                        document.getElementById('csvExpandColumnsBtn').click();
                    }
                    
                    // Auto-size columns
                    table.style.tableLayout = 'auto';
                    
                    // After rendering, fix the width values
                    setTimeout(() => {
                        const headers = Array.from(headerRow.children);
                        const containerWidth = tableContainer.clientWidth;
                        const totalColumns = headers.length;
                        
                        // Calculate all widths first
                        const widths = headers.map(th => th.offsetWidth);
                        const totalWidth = widths.reduce((sum, width) => sum + width, 0);
                        
                        // If total width exceeds container, adjust proportionally
                        if (totalWidth > containerWidth) {
                            // Scale factor to make all columns fit within container
                            const scaleFactor = (containerWidth - 20) / totalWidth; // 20px buffer
                            
                            // Apply scaled width to each column
                            headers.forEach((th, index) => {
                                const newWidth = Math.max(80, Math.floor(widths[index] * scaleFactor));
                                th.style.width = `${newWidth}px`;
                                
                                // Apply the same width to all cells in this column
                                const colIndex = index;
                                const columnCells = table.querySelectorAll(`tr td:nth-child(${colIndex + 1})`);
                                columnCells.forEach(cell => {
                                    cell.style.width = `${newWidth}px`;
                                });
                            });
                        }
                        
                        // Switch back to fixed layout to respect the widths
                        table.style.tableLayout = 'fixed';
                    }, 10);
                    
                    // Trigger the fit columns action immediately on first load
                    setTimeout(() => {
                        document.getElementById('csvFixColumnWidthsBtn').click();
                    }, 100);
                });
            } catch (error) {
                console.error('Error parsing CSV:', error);
                
                // Fall back to text display
                const pre = document.createElement('pre');
                pre.textContent = fileContent;
                pre.id = 'snuAttatchmentContentPre';
                pre.style.overflow = 'auto';
                pre.style.whiteSpace = 'pre-wrap';
                pre.style.maxHeight = '94%';
                content.appendChild(pre);
            }
        }
        else if (['txt', 'log', 'xml', 'json', 'html', 'css', 'js', 'sql', 'md', 'eml', 'ics'].includes(att.extension)) {
            const content = document.querySelector('#snuAttatchmentContent');
            content.innerHTML = 'File is being loaded, please wait...';
            
            let fileContent = await fetch(`/sys_attachment.do?sys_id=${att.sys_id}`).then(response => response.text());
            content.innerHTML = '';
            let span = document.createElement('span');
            span.innerHTML = `
            Download: <a href="/sys_attachment.do?sys_id=${att.sys_id}">${att.file_name}</a> | 
            <a href="#" title="[SN Utils] Copy result to clipboard" onclick="snuCopyAttatchmentContent()" >
            <svg class="w-6 h-6 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" stroke-linejoin="round" stroke-width="2" d="M9 8v3a1 1 0 0 1-1 1H5m11 4h2a1 1 0 0 0 1-1V5a1 1 0 0 0-1-1h-7a1 1 0 0 0-1 1v1m4 3v10a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1v-7.13a1 1 0 0 1 .24-.65L7.7 8.35A1 1 0 0 1 8.46 8H13a1 1 0 0 1 1 1Z"/>
            </svg>
            </a><span id="actionResult"></span>`;
            content.appendChild(span);

            const pre = document.createElement('pre');
            pre.textContent = fileContent;
            pre.id = 'snuAttatchmentContentPre';
            pre.style.overflow = 'auto';
            pre.style.whiteSpace = 'pre-wrap';
            pre.style.maxHeight = '94%';
            content.appendChild(pre);
        }
        else if (['msg'].includes(att.extension)) {
            // Handle .msg files if the necessary libraries are available
            // This is a placeholder - you would need to implement MSG reading functionality
            // similar to the original implementation
            const content = document.querySelector('#snuAttatchmentContent');
            content.innerHTML = '.msg file preview not supported in this version';
        }
        else {
            const content = document.querySelector('#snuAttatchmentContent');
            content.innerHTML = '';
            const a = document.createElement('a');
            a.href = `/sys_attachment.do?sys_id=${att.sys_id}`;
            a.textContent = `${att.file_name} Filetype not supported, download attachment`;
            a.style.display = 'block';
            content.appendChild(a);
        }
    }

    /**
     * Copy attachment content to clipboard
     */
    async function snuCopyAttatchmentContent() {
        const pre = document.getElementById('snuAttatchmentContentPre');
        if (pre) {
            try {
                await navigator.clipboard.writeText(pre.textContent);
                document.getElementById('actionResult').textContent = ' Copied!';
                setTimeout(() => {
                    document.getElementById('actionResult').textContent = '';
                }, 2000);
            } catch (err) {
                console.error('Failed to copy: ', err);
                document.getElementById('actionResult').textContent = ' Copy failed!';
            }
        }
    }

    /**
     * Add preview links to attachments in the UI
     */
    function snuAddPreviewAttachmentLinks() {
        // Check if we're in UI Builder context
        const isUIBuilder = window.NOW && window.NOW.UXF;
        
        if (isUIBuilder) {
            // For UI Builder, we need to find attachment elements differently
            setTimeout(() => {
                const attachmentList = document.querySelector('now-record-attachment-list');
                if (!attachmentList) return;
                
                // Find the Shadow DOM root if it exists
                const shadowRoot = attachmentList.shadowRoot || attachmentList;
                
                // Find attachment items - adjust selector based on UI Builder's structure
                const attachmentItems = shadowRoot.querySelectorAll('.attachment-item');
                
                attachmentItems.forEach(item => {
                    // Skip if already processed
                    if (item.querySelector('.snu-preview-link')) return;
                    
                    // Get attachment ID
                    const attLink = item.querySelector('a[aria-label*="Download"]');
                    if (!attLink) return;
                    
                    const href = attLink.getAttribute('href');
                    const attSysId = href.match(/sys_id=([^&]+)/)?.[1];
                    
                    if (attSysId) {
                        const previewLink = document.createElement('a');
                        previewLink.innerHTML = '[⌕]&nbsp;';
                        previewLink.className = 'snu-preview-link';
                        previewLink.title = '[SN Utils] Open Preview attachments modal';
                        previewLink.style.cursor = 'pointer';
                        previewLink.style.marginRight = '5px';
                        previewLink.onclick = () => snuPreviewAttachmentsModal(attSysId);
                        
                        // Insert before the first child or add to the beginning
                        const firstChild = item.firstChild;
                        if (firstChild) {
                            item.insertBefore(previewLink, firstChild);
                        } else {
                            item.appendChild(previewLink);
                        }
                    }
                });
            }, 1000);
        } 
        else if (typeof g_form !== 'undefined') {
            // Classic UI
            let attachments = document.querySelectorAll('li.attachment_list_items, li.manage_list');
            attachments.forEach(attachment => {
                let attSysId = attachment?.firstChild?.id?.replace('attachment_', '') || '';
                let pvw = document.createElement('a');
                pvw.innerHTML = "[⌕]&nbsp;";
                pvw.title = "[SN Utils] Open Preview attachments modal";
                pvw.onclick = () => snuPreviewAttachmentsModal(attSysId);
                if (attachment.classList.contains('attachment_list_items')) 
                    attachment.querySelector('span').appendChild(pvw);
                if (attachments.length > 1 && attachment.classList.contains('manage_list')) 
                    attachment.insertBefore(pvw, attachment.firstChild);
            });
        }
    }

    /**
     * Helper function to parse CSV lines properly handling quoted fields
     * @param {string} line - The CSV line to parse
     * @return {Array} Array of cell values
     */
    function parseCSVLine(line) {
        const result = [];
        let currentCell = "";
        let inQuotes = false;
        
        for (let i = 0; i < line.length; i++) {
            const char = line[i];
            const nextChar = line[i + 1];
            
            if (char === '"' && !inQuotes) {
                // Start of quoted field
                inQuotes = true;
            } else if (char === '"' && inQuotes) {
                // Check for escaped quotes
                if (nextChar === '"') {
                    currentCell += '"';
                    i++; // Skip the next quote
                } else {
                    // End of quoted field
                    inQuotes = false;
                }
            } else if (char === ',' && !inQuotes) {
                // End of cell
                result.push(currentCell);
                currentCell = "";
            } else {
                currentCell += char;
            }
        }
        
        // Add the last cell
        result.push(currentCell);
        
        return result;
    }

    // Export functions to global scope
    window.snuPreviewAttachmentsModal = snuPreviewAttachmentsModal;
    window.snuSetAttachmentPreview = snuSetAttachmentPreview;
    window.snuCopyAttatchmentContent = snuCopyAttatchmentContent;
    window.snuAddPreviewAttachmentLinks = snuAddPreviewAttachmentLinks;

    // Automatically add preview links when the script loads
    document.addEventListener('DOMContentLoaded', () => {
        snuAddPreviewAttachmentLinks();
        
        // For UI Builder, we need to observe DOM changes
        if (window.NOW && window.NOW.UXF) {
            // Create a MutationObserver to watch for attachment list changes
            const observer = new MutationObserver((mutations) => {
                const hasRelevantChanges = mutations.some(mutation => {
                    return mutation.addedNodes.length > 0 || 
                           (mutation.target.tagName === 'NOW-RECORD-ATTACHMENT-LIST' ||
                            mutation.target.classList?.contains('attachment-item'));
                });
                
                if (hasRelevantChanges) {
                    snuAddPreviewAttachmentLinks();
                }
            });
            
            // Start observing the document body
            observer.observe(document.body, { 
                childList: true, 
                subtree: true,
                attributes: true,
                attributeFilter: ['class']
            });
        }
    });
})();
