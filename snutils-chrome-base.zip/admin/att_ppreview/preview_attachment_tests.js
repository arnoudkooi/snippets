/**
 * ServiceNow Utils Attachment Preview Test Suite
 * 
 * This script provides testing functionality for the attachment preview wrapper.
 * It can be run in the browser console to verify the functionality in both Classic UI and UI Builder.
 */

// Test Suite for SN Utils Attachment Preview Wrapper
const SNUAttachmentPreviewTests = {
    /**
     * Run all tests
     */
    runAll: function() {
        console.log('%c[SN Utils] Running Attachment Preview Test Suite', 'color: blue; font-weight: bold');
        
        // Detect environment
        const isUIBuilder = window.NOW && window.NOW.UXF;
        console.log(`%c[Test] Environment: ${isUIBuilder ? 'UI Builder' : 'Classic UI'}`, 'color: purple');
        
        // Run tests
        this.testFunctionAvailability();
        this.testModalConstruction();
        this.testAttachmentLinks();
        
        console.log('%c[SN Utils] Test Suite Complete', 'color: blue; font-weight: bold');
    },
    
    /**
     * Test if required functions are available
     */
    testFunctionAvailability: function() {
        console.log('%c[Test] Checking function availability...', 'color: green');
        
        const requiredFunctions = [
            'snuPreviewAttachmentsModal',
            'snuSetAttachmentPreview',
            'snuCopyAttatchmentContent',
            'snuAddPreviewAttachmentLinks'
        ];
        
        let allAvailable = true;
        requiredFunctions.forEach(fnName => {
            const isAvailable = typeof window[fnName] === 'function';
            console.log(`%c[Test] ${fnName}: ${isAvailable ? 'Available ✓' : 'Missing ✗'}`, 
                        isAvailable ? 'color: green' : 'color: red; font-weight: bold');
            if (!isAvailable) allAvailable = false;
        });
        
        return allAvailable;
    },
    
    /**
     * Test modal construction
     */
    testModalConstruction: function() {
        console.log('%c[Test] Testing modal construction...', 'color: green');
        
        try {
            // Create a mock attachment object
            const mockAttachment = {
                sys_id: 'test_sys_id',
                file_name: 'test_file.txt',
                content_type: 'text/plain',
                extension: 'txt',
                size_bytes: '1024',
                sys_updated_by: 'test_user',
                sys_updated_on: '2023-01-01'
            };
            
            // Test creating container elements
            const container = document.createElement('div');
            container.id = 'test-container';
            container.innerHTML = `
                <div id="snuAttachmentPreview">
                    <div id="snuAttatchmentNav">
                        <input type="search" id="snuFilterAttachmentsInput">
                        <ul></ul>
                    </div>
                    <div id="snuAttatchmentContent"></div>
                </div>
            `;
            
            document.body.appendChild(container);
            
            // Check if elements were created
            const navPresent = !!document.querySelector('#snuAttatchmentNav');
            const contentPresent = !!document.querySelector('#snuAttatchmentContent');
            const searchPresent = !!document.querySelector('#snuFilterAttachmentsInput');
            
            console.log(`%c[Test] Navigation panel: ${navPresent ? 'Created ✓' : 'Failed ✗'}`, 
                        navPresent ? 'color: green' : 'color: red');
            console.log(`%c[Test] Content panel: ${contentPresent ? 'Created ✓' : 'Failed ✗'}`, 
                        contentPresent ? 'color: green' : 'color: red');
            console.log(`%c[Test] Search input: ${searchPresent ? 'Created ✓' : 'Failed ✗'}`, 
                        searchPresent ? 'color: green' : 'color: red');
            
            // Clean up
            document.body.removeChild(container);
            
            return navPresent && contentPresent && searchPresent;
            
        } catch (error) {
            console.error(`%c[Test] Modal construction error: ${error.message}`, 'color: red; font-weight: bold');
            return false;
        }
    },
    
    /**
     * Test attachment links
     */
    testAttachmentLinks: function() {
        console.log('%c[Test] Testing attachment links...', 'color: green');
        
        // Check if we're in a context with attachments
        const isUIBuilder = window.NOW && window.NOW.UXF;
        
        try {
            if (isUIBuilder) {
                // Check for UI Builder attachment list
                const attachmentList = document.querySelector('now-record-attachment-list');
                if (!attachmentList) {
                    console.log('%c[Test] No attachment list found in UI Builder', 'color: orange');
                    return false;
                }
                
                // Try to add preview links
                if (typeof snuAddPreviewAttachmentLinks === 'function') {
                    snuAddPreviewAttachmentLinks();
                    console.log('%c[Test] Added preview links to UI Builder attachments', 'color: green');
                }
                
                // Check for preview links (might be in shadow DOM)
                setTimeout(() => {
                    const links = document.querySelectorAll('.snu-preview-link');
                    console.log(`%c[Test] Found ${links.length} preview links in UI Builder`, 
                               links.length > 0 ? 'color: green' : 'color: orange');
                }, 1000);
                
            } else {
                // Classic UI
                const attachmentItems = document.querySelectorAll('li.attachment_list_items, li.manage_list');
                if (attachmentItems.length === 0) {
                    console.log('%c[Test] No attachment items found in Classic UI', 'color: orange');
                    return false;
                }
                
                // Try to add preview links
                if (typeof snuAddPreviewAttachmentLinks === 'function') {
                    snuAddPreviewAttachmentLinks();
                    console.log('%c[Test] Added preview links to Classic UI attachments', 'color: green');
                }
                
                // Count preview links
                setTimeout(() => {
                    // Look for our preview links by content/title
                    const links = Array.from(document.querySelectorAll('a')).filter(
                        a => a.title === "[SN Utils] Open Preview attachments modal" || 
                             a.innerHTML.includes("[⌕]")
                    );
                    
                    console.log(`%c[Test] Found ${links.length} preview links in Classic UI`, 
                               links.length > 0 ? 'color: green' : 'color: orange');
                }, 1000);
            }
            
            return true;
            
        } catch (error) {
            console.error(`%c[Test] Attachment links error: ${error.message}`, 'color: red; font-weight: bold');
            return false;
        }
    },
    
    /**
     * Test opening the preview modal
     * @param {string} attSysId - Optional attachment sys_id to preview
     */
    testOpenModal: function(attSysId) {
        console.log('%c[Test] Testing modal opening...', 'color: green');
        
        try {
            if (typeof snuPreviewAttachmentsModal !== 'function') {
                console.error('%c[Test] snuPreviewAttachmentsModal function not available', 'color: red');
                return false;
            }
            
            // If no sys_id provided, try to find one
            if (!attSysId) {
                const isUIBuilder = window.NOW && window.NOW.UXF;
                
                if (isUIBuilder) {
                    // In UI Builder, look for attachment links in the DOM
                    const attachLinks = document.querySelectorAll('a[aria-label*="Download"]');
                    if (attachLinks.length > 0) {
                        const href = attachLinks[0].getAttribute('href');
                        attSysId = href.match(/sys_id=([^&]+)/)?.[1];
                    }
                } else {
                    // In Classic UI
                    const attachItems = document.querySelectorAll('li.attachment_list_items, li.manage_list');
                    if (attachItems.length > 0) {
                        attSysId = attachItems[0]?.firstChild?.id?.replace('attachment_', '') || '';
                    }
                }
            }
            
            if (attSysId) {
                console.log(`%c[Test] Opening modal for attachment sys_id: ${attSysId}`, 'color: green');
                snuPreviewAttachmentsModal(attSysId);
                return true;
            } else {
                console.log('%c[Test] No attachment sys_id found to test modal', 'color: orange');
                return false;
            }
            
        } catch (error) {
            console.error(`%c[Test] Modal opening error: ${error.message}`, 'color: red; font-weight: bold');
            return false;
        }
    }
};

// Make test suite available globally
window.SNUAttachmentPreviewTests = SNUAttachmentPreviewTests;

// Instructions for running tests
console.log(`%c
ServiceNow Utils Attachment Preview Test Suite

To run all tests:
    SNUAttachmentPreviewTests.runAll()

To test opening modal:
    SNUAttachmentPreviewTests.testOpenModal() 
    
To test with a specific attachment:
    SNUAttachmentPreviewTests.testOpenModal('sys_id_of_attachment')
`, 'color: blue; font-weight: bold');
